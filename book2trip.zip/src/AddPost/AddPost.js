import React from 'react';

const AddPost = () => {
    return (
        <form>
            form
        </form>
    );
}

export default AddPost;